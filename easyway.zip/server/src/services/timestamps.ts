const timeStamps = {
    timestamps: {
        createdAt: 'created_at',
        updatedAt: 'updated_at'
    }
}

export default timeStamps;