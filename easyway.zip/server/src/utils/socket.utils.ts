// import { app } from "../server";


// export let io;

// export const initSocket = () => {
//     io = require("socket.io")(app.httpServer, {
//         cors: {
//             origin: "http://localhost:10004",
//             methods: ["GET", "POST"],
//         }
//     });
//     io.on('connection', (socket) => {
//         console.log('Connected');
//         socket.join('default_room')
//     });


// }



