type ILoginRequest = {
    username: string;
}

export default ILoginRequest