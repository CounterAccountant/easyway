
type IPostMessageResponse = {
    success: boolean;
}

export default IPostMessageResponse