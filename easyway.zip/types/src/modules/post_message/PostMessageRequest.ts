type IPostMessageRequest = {
    sender_id: string;
    message: string;
}

export default IPostMessageRequest