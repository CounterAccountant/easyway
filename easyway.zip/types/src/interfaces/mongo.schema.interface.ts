
export default interface IMongoSchema {
    _id?: string;
    created_at?: Date;
    updated_at?: Date;
}